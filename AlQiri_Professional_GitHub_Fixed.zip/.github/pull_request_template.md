## What changed?

<!-- Describe the change briefly. -->

## Why?

<!-- Explain the user or engineering problem. -->

## Testing

- [ ] `gradle :app:assembleDebug`
- [ ] Tested on Android device/emulator
- [ ] No secrets/API keys added
- [ ] Documentation updated if needed

## Permissions / privacy impact

<!-- Explain any new or changed sensitive permission. Write "None" if not applicable. -->
